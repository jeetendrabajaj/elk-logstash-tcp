package com.arth.ipf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IpfServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
