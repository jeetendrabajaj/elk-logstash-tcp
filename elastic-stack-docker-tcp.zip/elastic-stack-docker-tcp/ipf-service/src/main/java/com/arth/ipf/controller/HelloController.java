package com.arth.ipf.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

@RestController
@Slf4j
public class HelloController {

    @RequestMapping(value = "/elkdemo")
    public String helloWorld(){
        String response = "Hello user ! " + new Date();
        log.trace("Logging at TRACE level");
        log.debug("Logging at DEBUG level");
        log.info("Logging at INFO level");
        log.warn("Logging at WARN level");
        log.error("Logging at ERROR level");
        log.error("Logging at TEST level");
        log.info("/elkdemo - &gt; " + response);

        return response;
    }
}
