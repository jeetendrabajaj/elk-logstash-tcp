package com.arth.ipf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IpfServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(IpfServiceApplication.class, args);
	}

}
